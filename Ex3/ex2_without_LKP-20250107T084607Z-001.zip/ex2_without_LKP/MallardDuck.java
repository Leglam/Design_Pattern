public class MallardDuck extends Duck {
    public void display() {
        System.out.println("I am Mallard Duck");
    }
}
