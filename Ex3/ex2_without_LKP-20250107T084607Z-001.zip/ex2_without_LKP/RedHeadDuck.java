public class RedHeadDuck extends Duck {
    public void display() {
        System.out.println("I am RedHead Duck ");
    }
}
