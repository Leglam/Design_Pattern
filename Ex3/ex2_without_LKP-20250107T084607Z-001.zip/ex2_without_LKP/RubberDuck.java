public class RubberDuck extends Duck {
    public void display() {
        System.out.println("I am Rubber Duck");
    }
}
