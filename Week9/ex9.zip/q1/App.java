public class App {
    public static void main(String[] args) {
        IImage myImage = new Image("test.jpg");
        //do something
        myImage.display();        
    }
}
