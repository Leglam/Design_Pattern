public interface IImage {
    void display();
}