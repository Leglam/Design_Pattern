public class Sprinkler {
    public void doSprinkler(Alarm alarm) {
        System.out.println("I am sprinkler,... doing my task");
        alarm.endAlarm("Sprinkler");
    }
}
